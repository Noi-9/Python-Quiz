
import sqlite3
def create():
    conn = sqlite3.connect('Question.db')
    c = conn.cursor()
    c.execute("""
    CREATE TABLE question (
	question_id integer PRIMARY KEY,
	question text NOT NULL,
	answer integer
)
    """)
    
    c.execute("""
    CREATE TABLE options (
    option_id   INTEGER PRIMARY KEY,
    options_value TEXT    NOT NULL,
    question_id      INTEGER NOT NULL,
    FOREIGN KEY (question_id)
    REFERENCES question (question_id) 
)
    """)     
    
    
    
    conn.commit()
    conn.close()
    return
# create()

def insert():
    conn1 = sqlite3.connect('Question.db')
    c = conn1.cursor()
    c.execute("INSERT INTO question (question ,answer) VALUES ( 'Q1. Is Python case sensitive when dealing with identifiers?',1),('Q2. Which of the following is invalid??',2),('Q3.Which of the following is an invalid variable??',3),('Q4. Which of the following is not a complex number?',4) ;")
 
    
    c.execute("INSERT INTO options (options_value,question_id) VALUES('Yes',1),('No',1),('Machine dependent',1),('None of the mentioned',1),('_a = 1',2),('__a = 1',2) ,('__str__ = 1',2),( 'None of the mentioned',2),('my_string_1',3),('1st_string',3),('Foo',3),('_',3),('k = 2 + 3j',4),('k = complex(2, 3)',4),('k ,= 2 + 3l',4),('k = 2 + 3j',4)")
    conn1.commit()
    conn1.close()
    
def select():
	conn = sqlite3.connect('Question.db')
	cursor = conn.cursor()
	cursor2 = conn.cursor()
	cursor3 = conn.cursor()
	data2 ={'question':[],'options':[],'answer':[]}
    try:
	   cursor.execute("SELECT * FROM question;") # Get address details by ID
        for row in cursor:
            data2['question'].append(row[1])
            data2['answer'].append(row[2])
            cursor2.execute("SELECT * FROM options WHERE question_id= " + str(row[0]) + ";") 
            ARRAY=[]
            for a in cursor2:
            ARRAY.append(a[1])
            data2['options'].append(ARRAY)
        return data2     
    finally:
        conn.close()    
		
		
try:
	create()
	insert()
except Exception as e:
            print("data base  created ")